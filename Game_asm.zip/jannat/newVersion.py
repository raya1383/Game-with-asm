import pygame
import math
import random
import sys
import colorsys  # برای تبدیل HSV به RGB
import time

def get_user_input(screen, prompt, font, clock):
    """
    نمایش یک لایه ورودی به همراه prompt برای دریافت ورودی کاربر.
    هنگام زدن Enter، رشته‌ی واردشده برگردانده می‌شود.
    """
    input_text = ""
    active = True

    # ایجاد یک لایه نیمه شفاف
    overlay = pygame.Surface(screen.get_size())
    overlay.set_alpha(200)
    overlay.fill((255, 255, 255))  # پس‌زمینه سفید برای لایه

    black = (0, 0, 0)

    while active:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    active = False
                elif event.key == pygame.K_BACKSPACE:
                    input_text = input_text[:-1]
                else:
                    input_text += event.unicode

        # نمایش لایه به همراه prompt و ورودی فعلی
        screen.blit(overlay, (0, 0))
        prompt_surface = font.render(prompt, True, black)
        input_surface = font.render(input_text, True, black)
        screen.blit(prompt_surface, (50, screen.get_height() // 2 - 50))
        screen.blit(input_surface, (50, screen.get_height() // 2))
        pygame.display.flip()
        clock.tick(30)
    return input_text

def create_ball_surface(color, radius):
    """
    یک سطح ایجاد می‌کند که یک دایره (توپ) با رنگ و شعاع داده‌شده رسم می‌کند 
    و یک صلیب سیاه در وسط آن ترسیم می‌کند.
    """
    surf = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
    pygame.draw.circle(surf, color, (radius, radius), radius)
    cross_color = (0, 0, 0)
    line_width = max(1, radius // 5)
    pygame.draw.line(surf, cross_color, (0, radius), (radius * 2, radius), line_width)
    pygame.draw.line(surf, cross_color, (radius, 0), (radius, radius * 2), line_width)
    return surf

def get_rainbow_color(hue):
    """
    دریافت یک رنگ (R,G,B) بر اساس hue در بازه‌ی [0,1].
    """
    r, g, b = colorsys.hsv_to_rgb(hue, 1, 1)
    return (int(r * 255), int(g * 255), int(b * 255))

def draw_menu(screen, font):
    """نمایش منوی اصلی برای انتخاب حالت بازی."""
    screen.fill((0, 0, 0))
    title_text = font.render("Ball Throwing Game", True, (255, 255, 255))
    single_text = font.render("1. Single Player", True, (255, 255, 255))
    cpu_text = font.render("2. Play with CPU", True, (255, 255, 255))
    screen.blit(title_text, (screen_width//2 - title_text.get_width()//2, screen_height//2 - 100))
    screen.blit(single_text, (screen_width//2 - single_text.get_width()//2, screen_height//2))
    screen.blit(cpu_text, (screen_width//2 - cpu_text.get_width()//2, screen_height//2 + 50))
    pygame.display.flip()

# ------------- تنظیمات اولیه -----------------
pygame.init()
screen_width, screen_height = 1200, 800
allowed_width = 300        # منطقه سمت چپ برای حرکت دستی توپ
ball_radius = 20           # شعاع توپ
blue_size = 150            # اندازه سبد (هدف): 150x150
move_speed = 5             # سرعت حرکت دستی
throw_speed = 5            # سرعت پایه برای پرتاب‌هایی که با سرعت ثابت هستند
gravity = 0.5              # شتاب گرانش برای پرتاب گرانشی ("x")

screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Ball Throwing Game")
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 36)

# ------------- بارگذاری تصاویر -----------------
try:
    background = pygame.image.load("background.jpg").convert()
except Exception as e:
    print("Error loading background.jpg:", e)
    pygame.quit()
    sys.exit()
background = pygame.transform.scale(background, (screen_width, screen_height))

try:
    basket_img = pygame.image.load("basket.png").convert_alpha()
except Exception as e:
    print("Error loading basket.png:", e)
    pygame.quit()
    sys.exit()
basket_img = pygame.transform.scale(basket_img, (blue_size, blue_size))

# منطقه مجاز (سمت چپ)
allowed_rect = pygame.Rect(0, 0, allowed_width, screen_height)
def get_blue_square_pos():
    """موقعیت تصادفی برای هدف (خارج از منطقه مجاز) برمی‌گرداند."""
    x = random.randint(allowed_width, screen_width - blue_size)
    y = random.randint(0, screen_height - blue_size)
    return [x, y]

# ------------- حلقه بیرونی برای منو و بازی -----------------
while True:
    # نمایش منوی اصلی
    menu = True
    game_mode = None  # "single" یا "cpu"
    while menu:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    game_mode = "single"
                    menu = False
                elif event.key == pygame.K_2:
                    game_mode = "cpu"
                    menu = False
        draw_menu(screen, font)
        clock.tick(60)
    
    # ------------- مقداردهی اولیه متغیرهای بازی -----------------
    ball_pos = [allowed_rect.centerx, allowed_rect.centery]
    prev_ball_pos = ball_pos.copy()
    blue_pos = get_blue_square_pos()
    score = 0

    # وضعیت‌های بازی:
    # "ready"    – در انتظار انتخاب یا حرکت دستی.
    # "pre_throw"– آماده شدن برای پرتاب (تاخیر 2 ثانیه‌ای)
    # "thrown"   – توپ در حال پرواز.
    # "laser"    – افکت لیزری در صورت پایان مسیر پرتاب.
    # "hit"      – توپ به هدف برخورد کرده.
    # "reset"    – آماده‌سازی مجدد توپ و هدف پس از هر پرتاب.
    state = "ready"
    throw_type = None
    throw_params = {}
    ball_start = ball_pos.copy()
    traveled_distance = 0
    vx = vy = 0
    laser_timer = 0
    hit_timer = 0
    pre_throw_start_time = None
    ball_angle = 0
    ball_hue = 0.0

    # برای حالت بازی با CPU، متغیر نوبت و زمان انتظار CPU را تنظیم می‌کنیم.
    if game_mode == "cpu":
        turn = "player"  # "player" یا "cpu"
        cpu_wait_start = None

    # ------------- حلقه اصلی بازی -----------------
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                # فشردن Escape باعث خروج از بازی به منوی اصلی می‌شود.
                if event.key == pygame.K_ESCAPE:
                    running = False
                # در حالت "ready" ورودی‌های مربوط به پرتاب‌ها مدیریت می‌شود.
                if state == "ready":
                    if game_mode == "cpu" and turn == "player":
                        if event.type == pygame.KEYDOWN:
                            # در حالت بازی با CPU تنها اجازه پرتاب گرانشی (x) داده می‌شود.
                            if event.key == pygame.K_x:
                                user_input = get_user_input(screen, "Enter angle of throwing (in degrees):", font, clock)
                                try:
                                    angle_deg = float(user_input)
                                except Exception:
                                    print("Invalid input for angle. Aborting throw.")
                                    continue
                                user_input = get_user_input(screen, "Enter power (initial speed):", font, clock)
                                try:
                                    power = float(user_input)
                                except Exception:
                                    print("Invalid input for power. Aborting throw.")
                                    continue
                                throw_type = "x"
                                throw_params = {"angle": angle_deg, "power": power}
                                ball_start = ball_pos.copy()
                                angle_rad = math.radians(angle_deg)
                                vx = power * math.cos(angle_rad)
                                vy = -power * math.sin(angle_rad)
                                pre_throw_start_time = pygame.time.get_ticks()
                                state = "pre_throw"
                    elif game_mode == "single":
                        if event.type == pygame.KEYDOWN:
                            if event.key == pygame.K_n:
                                user_input = get_user_input(screen, "Enter throw length (in pixels) for straight throw:", font, clock)
                                try:
                                    throw_length = float(user_input)
                                except Exception:
                                    print("Invalid input for throw length. Aborting throw.")
                                    continue
                                throw_type = "n"
                                throw_params = {"length": throw_length}
                                ball_start = ball_pos.copy()
                                traveled_distance = 0
                                pre_throw_start_time = pygame.time.get_ticks()
                                state = "pre_throw"
                            elif event.key == pygame.K_s:
                                user_input = get_user_input(screen, "Enter wave length (in pixels):", font, clock)
                                try:
                                    wave_length = float(user_input)
                                except Exception:
                                    print("Invalid input for wave length. Aborting throw.")
                                    continue
                                user_input = get_user_input(screen, "Enter wave amplitude (in pixels):", font, clock)
                                try:
                                    wave_amplitude = float(user_input)
                                except Exception:
                                    print("Invalid input for wave amplitude. Aborting throw.")
                                    continue
                                throw_type = "s"
                                throw_params = {"wave_length": wave_length, "wave_amplitude": wave_amplitude}
                                ball_start = ball_pos.copy()
                                pre_throw_start_time = pygame.time.get_ticks()
                                state = "pre_throw"
                            elif event.key == pygame.K_a:
                                user_input = get_user_input(screen, "Enter angle of throwing (in degrees):", font, clock)
                                try:
                                    angle_deg = float(user_input)
                                except Exception:
                                    print("Invalid input for angle. Aborting throw.")
                                    continue
                                user_input = get_user_input(screen, "Enter throw length (in pixels):", font, clock)
                                try:
                                    throw_length = float(user_input)
                                except Exception:
                                    print("Invalid input for throw length. Aborting throw.")
                                    continue
                                throw_type = "a"
                                throw_params = {"angle": angle_deg, "length": throw_length}
                                ball_start = ball_pos.copy()
                                traveled_distance = 0
                                angle_rad = math.radians(angle_deg)
                                vx = throw_speed * math.cos(angle_rad)
                                vy = -throw_speed * math.sin(angle_rad)
                                pre_throw_start_time = pygame.time.get_ticks()
                                state = "pre_throw"
                            elif event.key == pygame.K_x:
                                user_input = get_user_input(screen, "Enter angle of throwing (in degrees):", font, clock)
                                try:
                                    angle_deg = float(user_input)
                                except Exception:
                                    print("Invalid input for angle. Aborting throw.")
                                    continue
                                user_input = get_user_input(screen, "Enter power (initial speed):", font, clock)
                                try:
                                    power = float(user_input)
                                except Exception:
                                    print("Invalid input for power. Aborting throw.")
                                    continue
                                throw_type = "x"
                                throw_params = {"angle": angle_deg, "power": power}
                                ball_start = ball_pos.copy()
                                angle_rad = math.radians(angle_deg)
                                vx = power * math.cos(angle_rad)
                                vy = -power * math.sin(angle_rad)
                                pre_throw_start_time = pygame.time.get_ticks()
                                state = "pre_throw"

        # --- پرتاب خودکار CPU -----------------
        if game_mode == "cpu" and turn == "cpu" and state == "ready":
            if cpu_wait_start is None:
                cpu_wait_start = pygame.time.get_ticks()
            elif pygame.time.get_ticks() - cpu_wait_start >= 1000:
                target_center_x = blue_pos[0] + blue_size / 2
                target_center_y = blue_pos[1] + blue_size / 2
                dx = target_center_x - ball_pos[0]
                dy = ball_pos[1] - target_center_y  # توجه به جهت محور y

                theta = math.radians(45)
                if dx * math.tan(theta) + dy <= 0:
                    theta = math.radians(30)
                denom = dx * math.tan(theta) + dy
                if denom <= 0:
                    v = 15
                else:
                    v = math.sqrt((gravity * dx * dx) / (2 * (math.cos(theta) ** 2) * (dx * math.tan(theta) + dy)))
                # افزودن خطای تصادفی برای زاویه و قدرت
                angle_deg = math.degrees(theta) + random.uniform(-10, 10)  # ±10 درجه خطا
                power = v * (1 + random.uniform(-0.2, 0.2))  # ±20 درصد خطا در قدرت
                throw_type = "x"
                throw_params = {"angle": angle_deg, "power": power}
                ball_start = ball_pos.copy()
                angle_rad = math.radians(angle_deg)
                vx = power * math.cos(angle_rad)
                vy = -power * math.sin(angle_rad)
                pre_throw_start_time = pygame.time.get_ticks()
                state = "pre_throw"
                cpu_wait_start = None

        # --- حالت "pre_throw": تاخیر 2 ثانیه‌ای قبل از پرتاب ---
        if state == "pre_throw":
            screen.blit(background, (0, 0))
            pygame.draw.rect(screen, (0, 0, 0), allowed_rect, 2)
            screen.blit(basket_img, (blue_pos[0], blue_pos[1]))
            score_text = font.render("Score: " + str(score), True, (0, 0, 0))
            screen.blit(score_text, (screen_width - 150, 10))
            ball_hue = (ball_hue + 0.005) % 1.0
            current_color = get_rainbow_color(ball_hue)
            if abs(ball_pos[0]-prev_ball_pos[0]) + abs(ball_pos[1]-prev_ball_pos[1]) > 0.5:
                ball_angle += 5
            ball_surf = create_ball_surface(current_color, ball_radius)
            rotated_ball = pygame.transform.rotate(ball_surf, ball_angle)
            rot_rect = rotated_ball.get_rect(center=(int(ball_pos[0]), int(ball_pos[1])))
            screen.blit(rotated_ball, rot_rect)
            pygame.display.flip()
            if pygame.time.get_ticks() - pre_throw_start_time >= 2000:
                state = "thrown"

        # --- حرکت دستی توپ (فقط در حالت "ready") ---
        if state == "ready":
            if not (game_mode == "cpu" and turn == "cpu"):
                keys = pygame.key.get_pressed()
                if keys[pygame.K_LEFT]:
                    ball_pos[0] -= move_speed
                if keys[pygame.K_RIGHT]:
                    ball_pos[0] += move_speed
                if keys[pygame.K_UP]:
                    ball_pos[1] -= move_speed
                if keys[pygame.K_DOWN]:
                    ball_pos[1] += move_speed
                if ball_pos[0] < ball_radius:
                    ball_pos[0] = ball_radius
                if ball_pos[0] > allowed_rect.width - ball_radius:
                    ball_pos[0] = allowed_rect.width - ball_radius
                if ball_pos[1] < ball_radius:
                    ball_pos[1] = ball_radius
                if ball_pos[1] > screen_height - ball_radius:
                    ball_pos[1] = screen_height - ball_radius

        # --- به‌روزرسانی موقعیت توپ در حالت "thrown" ---
        if state == "thrown":
            if throw_type == "n":
                ball_pos[0] += throw_speed
                traveled_distance = ball_pos[0] - ball_start[0]
                ball_rect = pygame.Rect(int(ball_pos[0] - ball_radius),
                                        int(ball_pos[1] - ball_radius),
                                        ball_radius * 2, ball_radius * 2)
                target_rect = pygame.Rect(blue_pos[0], blue_pos[1], blue_size, blue_size)
                if ball_rect.colliderect(target_rect):
                    score += 1
                    state = "hit"
                    hit_timer = 20
                elif traveled_distance >= throw_params["length"]:
                    state = "laser"
                    laser_timer = 20
            elif throw_type == "s":
                ball_pos[0] += throw_speed
                dx = ball_pos[0] - ball_start[0]
                ball_pos[1] = ball_start[1] + throw_params["wave_amplitude"] * math.sin(2 * math.pi * dx / throw_params["wave_length"])
                ball_rect = pygame.Rect(int(ball_pos[0] - ball_radius),
                                        int(ball_pos[1] - ball_radius),
                                        ball_radius * 2, ball_radius * 2)
                target_rect = pygame.Rect(blue_pos[0], blue_pos[1], blue_size, blue_size)
                if ball_rect.colliderect(target_rect):
                    score += 3
                    state = "hit"
                    hit_timer = 20
            elif throw_type == "a":
                ball_pos[0] += vx
                ball_pos[1] += vy
                dx = ball_pos[0] - ball_start[0]
                dy = ball_pos[1] - ball_start[1]
                traveled_distance = math.sqrt(dx * dx + dy * dy)
                ball_rect = pygame.Rect(int(ball_pos[0] - ball_radius),
                                        int(ball_pos[1] - ball_radius),
                                        ball_radius * 2, ball_radius * 2)
                target_rect = pygame.Rect(blue_pos[0], blue_pos[1], blue_size, blue_size)
                if ball_rect.colliderect(target_rect):
                    score += 2
                    state = "hit"
                    hit_timer = 20
                elif traveled_distance >= throw_params["length"]:
                    state = "laser"
                    laser_timer = 20
            elif throw_type == "x":
                ball_pos[0] += vx
                ball_pos[1] += vy
                vy += gravity
                ball_rect = pygame.Rect(int(ball_pos[0] - ball_radius),
                                        int(ball_pos[1] - ball_radius),
                                        ball_radius * 2, ball_radius * 2)
                target_rect = pygame.Rect(blue_pos[0], blue_pos[1], blue_size, blue_size)
                if ball_rect.colliderect(target_rect):
                    score += 5
                    state = "hit"
                    hit_timer = 20
            if not (0 <= ball_pos[0] <= screen_width and 0 <= ball_pos[1] <= screen_height):
                state = "reset"

        # --- حالت‌های "laser" و "hit" ---
        if state == "laser":
            laser_timer -= 1
            if laser_timer <= 0:
                state = "reset"
        if state == "hit":
            hit_timer -= 1
            if hit_timer <= 0:
                state = "reset"

        # --- حالت "reset": آماده‌سازی برای پرتاب بعدی ---
        if state == "reset":
            ball_pos = [allowed_rect.centerx, allowed_rect.centery]
            blue_pos = get_blue_square_pos()
            state = "ready"
            throw_type = None
            throw_params = {}
            if game_mode == "cpu":
                if turn == "player":
                    turn = "cpu"
                else:
                    turn = "player"
                cpu_wait_start = None

        # --- رسم اجزاء صفحه ---
        screen.blit(background, (0, 0))
        pygame.draw.rect(screen, (0, 0, 0), allowed_rect, 2)
        screen.blit(basket_img, (blue_pos[0], blue_pos[1]))
        score_text = font.render("Score: " + str(score), True, (0, 0, 0))
        screen.blit(score_text, (screen_width - 150, 10))
        if game_mode == "cpu":
            turn_text = "Player's Turn" if turn == "player" else "CPU's Turn"
            turn_surface = font.render(turn_text, True, (0, 0, 0))
            screen.blit(turn_surface, (50, 50))
        if state == "laser":
            pygame.draw.line(screen, (0, 255, 0), (screen_width, 0),
                             (int(ball_pos[0]), int(ball_pos[1])), 3)
        ball_hue = (ball_hue + 0.005) % 1.0
        current_color = get_rainbow_color(ball_hue)
        if abs(ball_pos[0]-prev_ball_pos[0]) + abs(ball_pos[1]-prev_ball_pos[1]) > 0.5:
            ball_angle += 5
        ball_surf = create_ball_surface(current_color, ball_radius)
        rotated_ball = pygame.transform.rotate(ball_surf, ball_angle)
        rot_rect = rotated_ball.get_rect(center=(int(ball_pos[0]), int(ball_pos[1])))
        screen.blit(rotated_ball, rot_rect)

        pygame.display.flip()
        clock.tick(60)
        prev_ball_pos = ball_pos.copy()

    # با فشردن Escape، حلقه بازی پایان می‌یابد و اجرای برنامه به منوی اصلی بازمی‌گردد.

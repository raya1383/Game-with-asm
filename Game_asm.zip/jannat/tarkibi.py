import pygame
import sys
import os
import math
from pygame.locals import *
import tkinter as tk
from tkinter import simpledialog
import ctypes
import time

# بارگذاری کتابخانه اسمبلی
lib = ctypes.CDLL('./libasm.so')

# تعریف نوع ورودی و خروجی توابع اسمبلی
lib._sin_asm.argtypes = [ctypes.c_float]
lib._sin_asm.restype = ctypes.c_float

lib._cos_asm.argtypes = [ctypes.c_float]
lib._cos_asm.restype = ctypes.c_float

lib._check_collision_asm.argtypes = [ctypes.c_float, ctypes.c_float]
lib._check_collision_asm.restype = ctypes.c_int

lib._move_ball_x_asm.argtypes = [ctypes.c_float, ctypes.c_float, ctypes.c_float]
lib._move_ball_x_asm.restype = ctypes.c_float

lib._move_ball_y_asm.argtypes = [ctypes.c_float, ctypes.c_float, ctypes.c_float]
lib._move_ball_y_asm.restype = ctypes.c_float

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

class Ball:
    def __init__(self, x, y, image_path):
        self.x = x
        self.y = y
        self.image = pygame.image.load(image_path)
        self.image = pygame.transform.scale(self.image, (80, 80))

    def get_x(self):
        return self.x

    def set_x(self, x):
        self.x = int(x)

    def get_y(self):
        return self.y

    def set_y(self, y):
        self.y = int(y)

    def get_image(self):
        return self.image

class Basket:
    def __init__(self, x, y, image_path):
        self.x = x
        self.y = y
        self.image = pygame.image.load(image_path)
        self.image = pygame.transform.scale(self.image, (450, 700))

    def get_x(self):
        return self.x

    def set_x(self, x):
        self.x = int(x)

    def get_y(self):
        return self.y

    def set_y(self, y):
        self.y = int(y)

    def get_image(self):
        return self.image

class Player:
    def __init__(self, x, y, image_path):
        self.x = x
        self.y = y
        self.image = pygame.image.load(image_path)
        self.image = pygame.transform.scale(self.image, (500, 500))

    def get_x(self):
        return self.x

    def set_x(self, x):
        self.x = int(x)

    def get_y(self):
        return self.y

    def set_y(self, y):
        self.y = int(y)

    def get_image(self):
        return self.image

class GameController:
    end_time=None
    def __init__(self, ball, basket, player):
        self.ball = ball
        self.basket = basket
        self.player = player
        self.remaining_shots = 5
        self.game_over = False
        self.score = 0
        self.rect_x = 1030
        self.rect_y = 400
        self.rect_width = 170
        self.rect_height = 70
        self.animation_timer = None

    def get_ball(self):
        return self.ball

    def get_basket(self):
        return self.basket

    def get_player(self):
        return self.player

    def move_ball_up(self):
        self.ball.set_y(self.ball.get_y() - 10)
        self.player.set_y(self.player.get_y() - 10)

    def move_ball_down(self):
        self.ball.set_y(self.ball.get_y() + 10)
        self.player.set_y(self.player.get_y() + 10)

    def move_ball_left(self):
        self.ball.set_x(self.ball.get_x() - 10)
        self.player.set_x(self.player.get_x() - 10)

    def move_ball_right(self):
        self.ball.set_x(self.ball.get_x() + 10)
        self.player.set_x(self.player.get_x() + 10)

    def get_score(self):
        return self.score

    def increment_score(self, points):
        self.score += points

    def reset_score(self):
        self.score = 0

    def animate_throw(self, angle, length):
        start_time=time.time()
        flag = False
        cos_value = lib._cos_asm(ctypes.c_float(angle))  # استفاده از اسمبلی برای cos
        sin_value = lib._sin_asm(ctypes.c_float(angle))  # استفاده از اسمبلی برای sin
        print(cos_value)
        print(sin_value)
        target_x = length * cos_value
        target_y = length * sin_value
    
        if self.animation_timer:
            pygame.time.set_timer(pygame.USEREVENT, 0)  # متوقف کردن تایمر قبلی

        def update():
            nonlocal target_x, target_y, flag
            reached_x = abs(self.ball.get_x() - target_x) <= 1
            reached_y = abs(self.ball.get_y() - target_y) <= 1

            x_in_screen = self.ball.get_x() < 1375
            y_in_screen = self.ball.get_y() > 15

            # حرکت توپ در جهت X
            if not reached_x and x_in_screen:
                self.ball.set_x(self.ball.get_x() + int(length * cos_value / 20))
            elif reached_x and x_in_screen:
                self.ball.set_x(target_x)

            # حرکت توپ در جهت Y
            if not reached_y and y_in_screen:
                self.ball.set_y(self.ball.get_y() - int(length * sin_value / 20))
            elif reached_y and y_in_screen:
                self.ball.set_y(target_y)

            # بررسی همپوشانی در هنگام سقوط
            if self.ball.get_y() >= target_y and self.check_collision():
                flag = True

            # توقف انیمیشن و شروع سقوط
            if (reached_x or reached_y) and not flag:
                pygame.time.set_timer(pygame.USEREVENT, 0)
                self.animate_fall(100,start_time)
            elif reached_x and reached_y and flag:
                pygame.time.set_timer(pygame.USEREVENT, 0)
                self.animate_fall(50,start_time)

            # خارج از صفحه
            if not x_in_screen or not y_in_screen:
                pygame.time.set_timer(pygame.USEREVENT, 0)
                self.animate_fall(0,start_time)

            # پایان انیمیشن
            if reached_x and reached_y:
                if flag:
                    print("Score!")
                    self.increment_score(200)
                    self.end_time=time.time()
                    print(self.end_time-start_time)
                else:
                    print("Miss!")
                    self.end_time=time.time()
                    print(self.end_time-start_time)
                self.remaining_shots -= 1
                
                if self.remaining_shots > 0:
                    self.reset_ball_and_player()
                else:
                    self.game_over = True
                    self.ask_to_play_again()
                self.animation_timer = None

        self.animation_timer = update
        pygame.time.set_timer(pygame.USEREVENT, 20)  # تنظیم تایمر

    def check_collision(self):
        ball_x = self.ball.get_x()
        ball_y = self.ball.get_y()
        # استفاده از اسمبلی برای بررسی برخورد
        collision = lib._check_collision_asm(ctypes.c_float(ball_x), ctypes.c_float(ball_y))
        return collision == 1

    def animate_sine_throw(self, angle):
     start_time=time.time()
     flag=False   
     radian = math.radians(angle)
     amplitude = 50
     frequency = 0.1
     start_x = self.ball.get_x()
     start_y = self.ball.get_y()
     t = 0

     def update():
        nonlocal t,flag
        t += 0.2
        new_x = int(start_x + t * 20)
        new_y = int(start_y + amplitude * math.sin(frequency * new_x))

        self.ball.set_x(new_x)
        self.ball.set_y(new_y)
        if self.check_collision():
            flag=True 
        if new_x >= 1385 or new_y <= 15 or new_y >= 885:
            pygame.time.set_timer(pygame.USEREVENT, 0)
            if flag:
                print("Score!")
                self.increment_score(150)
                self.end_time=time.time()
                print(self.end_time-start_time)
            else:
                print("Miss!")
                self.end_time=time.time()
                print(self.end_time-start_time)
            self.remaining_shots -= 1
            if self.remaining_shots > 0:
                self.reset_ball_and_player()
            else:
                self.game_over = True
                self.ask_to_play_again()

            # توقف انیمیشن پس از اتمام
            self.animation_timer = None

     pygame.time.set_timer(pygame.USEREVENT, 20)
     self.animation_timer = update

    def animate_parabolic_throw(self, angle, length):
     start_time=time.time()
     flag=False
     velocity = 25
     radian = math.radians(angle)
     v_x = length / (velocity * math.cos(radian))
     v_y = velocity * math.sin(radian)
     gravity = 9.81

     start_x = self.ball.get_x()
     start_y = self.ball.get_y()
     end_x = start_x + length
     t = 0

     def update():
        nonlocal t,flag
        t += 0.2
        new_x = int(start_x + v_x * t)
        new_y = int(start_y - (v_y * t - 0.5 * gravity * t * t))  # معادله حرکت سهمی

        self.ball.set_x(new_x)
        self.ball.set_y(new_y)
        if self.check_collision():
            flag=True

        # بررسی شرایط خروج توپ از صفحه
        if new_y <= 15 or new_x >= 1385 or new_x >= end_x or new_y >= 800:
            if flag:
             print("Score!")
             self.increment_score(200)
             self.end_time=time.time()
             print(self.end_time-start_time)
            else:
                print("Miss") 
                self.end_time=time.time()
                print(self.end_time-start_time)

            self.animation_timer = None  # توقف انیمیشن
            self.remaining_shots -= 1
            if self.remaining_shots > 0:
                self.reset_ball_and_player()
            else:
                self.game_over = True
                self.ask_to_play_again()

     self.animation_timer = update  
    def shoot_ball_straight(self, length):
     start_time=time.time()
     target_x = self.ball.get_x() + length
     target_y = self.ball.get_y()

     def update():
        if self.ball.get_x() < target_x:  # حرکت توپ به سمت راست
            self.ball.set_x(self.ball.get_x() + 20)
        else:
            self.animation_timer = None  # توقف انیمیشن پرتاب مستقیم
            self.animate_fall(100,start_time)  # شروع انیمیشن سقوط

     self.animation_timer = update  # تنظیم تابع update

    def animate_fall(self, score,start_time):
     
     flag = False

     def update():
        nonlocal flag
        if self.ball.get_y() < 875:  # حرکت توپ به سمت پایین
            self.ball.set_y(self.ball.get_y() + 18)
            if self.check_collision():  # بررسی برخورد با سبد
                flag = True
        else:
            pygame.time.set_timer(pygame.USEREVENT, 0)  # توقف تایمر
            if flag:
                print("Score!")
                self.increment_score(score)
                self.end_time=time.time()
                print(self.end_time-start_time)
            else:
                print("Miss!")
                self.end_time=time.time()
                print(self.end_time-start_time)
            self.remaining_shots -= 1
            if self.remaining_shots > 0:
                self.reset_ball_and_player()  # بازنشانی توپ و بازیکن
            else:
                self.game_over = True
                self.ask_to_play_again()  # درخواست ادامه بازی

            # توقف انیمیشن پس از اتمام
            self.animation_timer = None

     pygame.time.set_timer(pygame.USEREVENT, 20)  # تنظیم تایمر
     self.animation_timer = update  # تنظیم تابع update

    def reset_ball_and_player(self):
        self.ball.set_x(250)  # موقعیت اولیه توپ
        self.ball.set_y(320)
        self.player.set_x(5)  # موقعیت اولیه بازیکن
        self.player.set_y(130)

    def ask_to_play_again(self):
        root = tk.Tk()
        root.withdraw()  # پنهان کردن پنجره اصلی tkinter
        play_again = simpledialog.askstring("Game Over", "Play again? (yes/no)")
        if play_again and play_again.lower() == "yes":
            self.reset_score()
            self.remaining_shots = 5
            self.game_over = False
            self.reset_ball_and_player()
        else:
            pygame.quit()
            sys.exit()

class GameView:
    def __init__(self, game_controller):
        pygame.init()
        self.game_controller = game_controller
        self.screen = pygame.display.set_mode((1400, 900))
        self.clock = pygame.time.Clock()
        self.background_image = pygame.image.load("images/background.jpg")
        self.timer = pygame.time.set_timer(pygame.USEREVENT + 1, 20)

    def run(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.KEYDOWN:
                    self.handle_key_down(event.key)
                elif event.type == pygame.USEREVENT + 1:
                    self.repaint()

            if self.game_controller.animation_timer:
                self.game_controller.animation_timer()

            self.screen.blit(self.background_image, (0, 0))
            self.draw_game()
            pygame.display.update()
            self.clock.tick(60)

    def handle_key_down(self, key):
        if key == pygame.K_UP:
            self.game_controller.move_ball_up()
        elif key == pygame.K_DOWN:
            self.game_controller.move_ball_down()
        elif key == pygame.K_LEFT:
            self.game_controller.move_ball_left()
        elif key == pygame.K_RIGHT:
            self.game_controller.move_ball_right()
        elif key == pygame.K_s:
            angle_str = simpledialog.askstring("Input", "Enter angle:")
            length_str = simpledialog.askstring("Input", "Specify the length of the throw:")
            try:
                angle = float(angle_str)
                length = int(length_str)
                self.game_controller.animate_throw(angle, length)
            except ValueError:
                print("Invalid input!")
        elif key == pygame.K_r:
            length_str = simpledialog.askstring("Input", "Specify the length of the throw:")
            try:
                length = int(length_str)
                self.game_controller.shoot_ball_straight(length)
            except ValueError:
                print("Invalid input!")
        elif key == pygame.K_d:
            parabolic_angle_str = simpledialog.askstring("Input", "Enter parabolic angle:")
            length_str = simpledialog.askstring("Input", "Specify the length of the throw:")
            try:
                angle = float(parabolic_angle_str)
                length = int(length_str)
                self.game_controller.animate_parabolic_throw(angle, length)
            except ValueError:
                print("Invalid input!")
        elif key == pygame.K_x:
            sin_angle_str = simpledialog.askstring("Input", "Enter Sin angle:")
            try:
                angle = float(sin_angle_str)
                self.game_controller.animate_sine_throw(angle)
            except ValueError:
                print("Invalid input!")

    def draw_game(self):
        ball = self.game_controller.get_ball()
        basket = self.game_controller.get_basket()
        player = self.game_controller.get_player()

        self.screen.blit(player.get_image(), (player.get_x(), player.get_y(), 250, 250))
        self.screen.blit(ball.get_image(), (ball.get_x() - 10, ball.get_y() - 10, 40, 40))
        self.screen.blit(basket.get_image(), (basket.get_x(), basket.get_y(), 250, 450))

        font = pygame.font.SysFont("Arial", 30)
        score_text = font.render("Score: " + str(self.game_controller.get_score()), True, (255, 255, 255))
        self.screen.blit(score_text, (self.screen.get_width() - 150, 30))

    def repaint(self):
        self.screen.blit(self.background_image, (0, 0))
        self.draw_game()
        pygame.display.update()

if __name__ == "__main__":
    ball = Ball(250, 320, "images/Basketball.png")
    basket = Basket(950, 150, "images/basket.png")
    player = Player(5, 130, "images/player.png")
    game_controller = GameController(ball, basket, player)

    game_view = GameView(game_controller)
    game_view.run()
import pygame
import math
import random
import sys
import colorsys  # For converting HSV to RGB
import time
from ctypes import CDLL, c_double

# ==========================================================
# Load the assembly functions from the shared library.
# (Make sure to compile math_functions.asm into math_functions.so)
# ==========================================================
math_funcs = CDLL("./libmath_functions.so")

# update_coord: adds two doubles.
math_funcs.update_coord.argtypes = (c_double, c_double)
math_funcs.update_coord.restype = c_double

# calc_sin: computes sine of a double (radians) using x87 FSIN.
math_funcs.calc_sin.argtypes = (c_double,)
math_funcs.calc_sin.restype = c_double

# apply_gravity: adds velocity and gravity (both doubles).
math_funcs.apply_gravity.argtypes = (c_double, c_double)
math_funcs.apply_gravity.restype = c_double

# ==========================================================
# Helper functions (unchanged from before)
# ==========================================================
def get_user_input(screen, prompt, font, clock):
    input_text = ""
    active = True
    overlay = pygame.Surface(screen.get_size())
    overlay.set_alpha(200)
    overlay.fill((255, 255, 255))  # white background
    black = (0, 0, 0)
    while active:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    active = False
                elif event.key == pygame.K_BACKSPACE:
                    input_text = input_text[:-1]
                else:
                    input_text += event.unicode
        screen.blit(overlay, (0, 0))
        prompt_surface = font.render(prompt, True, black)
        input_surface = font.render(input_text, True, black)
        screen.blit(prompt_surface, (50, screen.get_height() // 2 - 50))
        screen.blit(input_surface, (50, screen.get_height() // 2))
        pygame.display.flip()
        clock.tick(30)
    return input_text

def create_ball_surface(color, radius):
    surf = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
    pygame.draw.circle(surf, color, (radius, radius), radius)
    cross_color = (0, 0, 0)
    line_width = max(1, radius // 5)
    pygame.draw.line(surf, cross_color, (0, radius), (radius * 2, radius), line_width)
    pygame.draw.line(surf, cross_color, (radius, 0), (radius, radius * 2), line_width)
    return surf

def get_rainbow_color(hue):
    r, g, b = colorsys.hsv_to_rgb(hue, 1, 1)
    return (int(r * 255), int(g * 255), int(b * 255))

def draw_menu(screen, font):
    screen.fill((0, 0, 0))
    title_text = font.render("Ball Throwing Game", True, (255, 255, 255))
    single_text = font.render("1. Single Player", True, (255, 255, 255))
    cpu_text = font.render("2. Play with CPU", True, (255, 255, 255))
    screen.blit(title_text, (screen_width // 2 - title_text.get_width() // 2, screen_height // 2 - 100))
    screen.blit(single_text, (screen_width // 2 - single_text.get_width() // 2, screen_height // 2))
    screen.blit(cpu_text, (screen_width // 2 - cpu_text.get_width() // 2, screen_height // 2 + 50))
    pygame.display.flip()

# ==========================================================
# Initial configuration
# ==========================================================
pygame.init()
screen_width, screen_height = 1200, 800
allowed_width = 300        # left region for manual ball movement
ball_radius = 20           # ball radius
blue_size = 150            # basket (target) size: 150x150
move_speed = 5             # manual movement speed
throw_speed = 5            # base speed for constant-speed throws
gravity = 0.5              # gravity acceleration

screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Ball Throwing Game")
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 36)

# ==========================================================
# Outer loop: show menu and run game; pressing Escape returns to menu.
# ==========================================================
while True:
    # -------------------- Menu --------------------
    menu = True
    game_mode = None  # "single" or "cpu"
    while menu:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    game_mode = "single"
                    menu = False
                elif event.key == pygame.K_2:
                    game_mode = "cpu"
                    menu = False
        draw_menu(screen, font)
        clock.tick(60)
    
    # -------------------- Load Images --------------------
    try:
        background = pygame.image.load("background.jpg").convert()
    except Exception as e:
        print("Error loading background.jpg:", e)
        pygame.quit()
        sys.exit()
    background = pygame.transform.scale(background, (screen_width, screen_height))

    try:
        basket_img = pygame.image.load("basket.png").convert_alpha()
    except Exception as e:
        print("Error loading basket.png:", e)
        pygame.quit()
        sys.exit()
    basket_img = pygame.transform.scale(basket_img, (blue_size, blue_size))

    # -------------------- Regions and Initial Variables --------------------
    allowed_rect = pygame.Rect(0, 0, allowed_width, screen_height)
    def get_blue_square_pos():
        x = random.randint(allowed_width, screen_width - blue_size)
        y = random.randint(0, screen_height - blue_size)
        return [x, y]

    ball_pos = [allowed_rect.centerx, allowed_rect.centery]
    prev_ball_pos = ball_pos.copy()
    blue_pos = get_blue_square_pos()
    score = 0

    # Game states: "ready", "pre_throw", "thrown", "laser", "hit", "reset"
    state = "ready"
    throw_type = None
    throw_params = {}
    ball_start = ball_pos.copy()
    traveled_distance = 0
    vx = vy = 0
    laser_timer = 0
    hit_timer = 0
    pre_throw_start_time = None
    ball_angle = 0
    ball_hue = 0.0

    # For CPU mode, manage turn-taking.
    if game_mode == "cpu":
        turn = "player"  # or "cpu"
        cpu_wait_start = None

    # ==========================================================
    # Main game loop (pressing Escape returns to the menu)
    # ==========================================================
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                # Press Escape to return to the main menu.
                if event.key == pygame.K_ESCAPE:
                    running = False
                # Only allow throw input when state is "ready"
                if state == "ready":
                    if game_mode == "cpu" and turn == "player":
                        if event.key == pygame.K_x:
                            user_input = get_user_input(screen, "Enter angle of throwing (in degrees):", font, clock)
                            try:
                                angle_deg = float(user_input)
                            except Exception:
                                print("Invalid input for angle. Aborting throw.")
                                continue
                            user_input = get_user_input(screen, "Enter power (initial speed):", font, clock)
                            try:
                                power = float(user_input)
                            except Exception:
                                print("Invalid input for power. Aborting throw.")
                                continue
                            throw_type = "x"
                            throw_params = {"angle": angle_deg, "power": power}
                            ball_start = ball_pos.copy()
                            angle_rad = math.radians(angle_deg)
                            vx = power * math.cos(angle_rad)
                            vy = -power * math.sin(angle_rad)
                            pre_throw_start_time = pygame.time.get_ticks()
                            state = "pre_throw"
                    elif game_mode == "single":
                        if event.key == pygame.K_n:
                            user_input = get_user_input(screen, "Enter throw length (in pixels) for straight throw:", font, clock)
                            try:
                                throw_length = float(user_input)
                            except Exception:
                                print("Invalid input for throw length. Aborting throw.")
                                continue
                            throw_type = "n"
                            throw_params = {"length": throw_length}
                            ball_start = ball_pos.copy()
                            traveled_distance = 0
                            pre_throw_start_time = pygame.time.get_ticks()
                            state = "pre_throw"
                        elif event.key == pygame.K_s:
                            user_input = get_user_input(screen, "Enter wave length (in pixels):", font, clock)
                            try:
                                wave_length = float(user_input)
                            except Exception:
                                print("Invalid input for wave length. Aborting throw.")
                                continue
                            user_input = get_user_input(screen, "Enter wave amplitude (in pixels):", font, clock)
                            try:
                                wave_amplitude = float(user_input)
                            except Exception:
                                print("Invalid input for wave amplitude. Aborting throw.")
                                continue
                            throw_type = "s"
                            throw_params = {"wave_length": wave_length, "wave_amplitude": wave_amplitude}
                            ball_start = ball_pos.copy()
                            pre_throw_start_time = pygame.time.get_ticks()
                            state = "pre_throw"
                        elif event.key == pygame.K_a:
                            user_input = get_user_input(screen, "Enter angle of throwing (in degrees):", font, clock)
                            try:
                                angle_deg = float(user_input)
                            except Exception:
                                print("Invalid input for angle. Aborting throw.")
                                continue
                            user_input = get_user_input(screen, "Enter throw length (in pixels):", font, clock)
                            try:
                                throw_length = float(user_input)
                            except Exception:
                                print("Invalid input for throw length. Aborting throw.")
                                continue
                            throw_type = "a"
                            throw_params = {"angle": angle_deg, "length": throw_length}
                            ball_start = ball_pos.copy()
                            traveled_distance = 0
                            angle_rad = math.radians(angle_deg)
                            vx = throw_speed * math.cos(angle_rad)
                            vy = -throw_speed * math.sin(angle_rad)
                            pre_throw_start_time = pygame.time.get_ticks()
                            state = "pre_throw"
                        elif event.key == pygame.K_x:
                            user_input = get_user_input(screen, "Enter angle of throwing (in degrees):", font, clock)
                            try:
                                angle_deg = float(user_input)
                            except Exception:
                                print("Invalid input for angle. Aborting throw.")
                                continue
                            user_input = get_user_input(screen, "Enter power (initial speed):", font, clock)
                            try:
                                power = float(user_input)
                            except Exception:
                                print("Invalid input for power. Aborting throw.")
                                continue
                            throw_type = "x"
                            throw_params = {"angle": angle_deg, "power": power}
                            ball_start = ball_pos.copy()
                            angle_rad = math.radians(angle_deg)
                            vx = power * math.cos(angle_rad)
                            vy = -power * math.sin(angle_rad)
                            pre_throw_start_time = pygame.time.get_ticks()
                            state = "pre_throw"

        # -------------------- CPU automatic throw --------------------
        if game_mode == "cpu" and turn == "cpu" and state == "ready":
            if cpu_wait_start is None:
                cpu_wait_start = pygame.time.get_ticks()
            elif pygame.time.get_ticks() - cpu_wait_start >= 1000:
                target_center_x = blue_pos[0] + blue_size / 2
                target_center_y = blue_pos[1] + blue_size / 2
                dx = target_center_x - ball_pos[0]
                dy = ball_pos[1] - target_center_y  # note: y axis increases downward
                theta = math.radians(45)
                if dx * math.tan(theta) + dy <= 0:
                    theta = math.radians(30)
                denom = dx * math.tan(theta) + dy
                if denom <= 0:
                    v = 15
                else:
                    v = math.sqrt((gravity * dx * dx) / (2 * (math.cos(theta) ** 2) * (dx * math.tan(theta) + dy)))
                # Add random error: ±10° and ±20% power.
                angle_deg = math.degrees(theta) + random.uniform(-10, 10)
                power = v * (1 + random.uniform(-0.2, 0.2))
                throw_type = "x"
                throw_params = {"angle": angle_deg, "power": power}
                ball_start = ball_pos.copy()
                angle_rad = math.radians(angle_deg)
                vx = power * math.cos(angle_rad)
                vy = -power * math.sin(angle_rad)
                pre_throw_start_time = pygame.time.get_ticks()
                state = "pre_throw"
                cpu_wait_start = None

        # -------------------- Pre-Throw Delay (2 seconds) --------------------
        if state == "pre_throw":
            screen.blit(background, (0, 0))
            pygame.draw.rect(screen, (0, 0, 0), allowed_rect, 2)
            screen.blit(basket_img, (blue_pos[0], blue_pos[1]))
            score_text = font.render("Score: " + str(score), True, (0, 0, 0))
            screen.blit(score_text, (screen_width - 150, 10))
            ball_hue = (ball_hue + 0.005) % 1.0
            current_color = get_rainbow_color(ball_hue)
            if abs(ball_pos[0] - prev_ball_pos[0]) + abs(ball_pos[1] - prev_ball_pos[1]) > 0.5:
                ball_angle += 5
            ball_surf = create_ball_surface(current_color, ball_radius)
            rotated_ball = pygame.transform.rotate(ball_surf, ball_angle)
            rot_rect = rotated_ball.get_rect(center=(int(ball_pos[0]), int(ball_pos[1])))
            screen.blit(rotated_ball, rot_rect)
            pygame.display.flip()
            if pygame.time.get_ticks() - pre_throw_start_time >= 2000:
                state = "thrown"

        # -------------------- Manual Movement (in state "ready") --------------------
        if state == "ready":
            # In CPU mode, do not allow manual movement on CPU's turn.
            if not (game_mode == "cpu" and turn == "cpu"):
                keys = pygame.key.get_pressed()
                if keys[pygame.K_LEFT]:
                    # Subtract move_speed by adding negative move_speed.
                    ball_pos[0] = float(math_funcs.update_coord(c_double(ball_pos[0]), c_double(-move_speed)))
                if keys[pygame.K_RIGHT]:
                    ball_pos[0] = float(math_funcs.update_coord(c_double(ball_pos[0]), c_double(move_speed)))
                if keys[pygame.K_UP]:
                    ball_pos[1] = float(math_funcs.update_coord(c_double(ball_pos[1]), c_double(-move_speed)))
                if keys[pygame.K_DOWN]:
                    ball_pos[1] = float(math_funcs.update_coord(c_double(ball_pos[1]), c_double(move_speed)))
                # Constrain the ball within the allowed region.
                if ball_pos[0] < ball_radius:
                    ball_pos[0] = ball_radius
                if ball_pos[0] > allowed_rect.width - ball_radius:
                    ball_pos[0] = allowed_rect.width - ball_radius
                if ball_pos[1] < ball_radius:
                    ball_pos[1] = ball_radius
                if ball_pos[1] > screen_height - ball_radius:
                    ball_pos[1] = screen_height - ball_radius

        # -------------------- Updating Ball Position When in "thrown" State --------------------
        if state == "thrown":
            if throw_type == "n":
                ball_pos[0] = float(math_funcs.update_coord(c_double(ball_pos[0]), c_double(throw_speed)))
                traveled_distance = ball_pos[0] - ball_start[0]
                ball_rect = pygame.Rect(int(ball_pos[0] - ball_radius),
                                        int(ball_pos[1] - ball_radius),
                                        ball_radius * 2, ball_radius * 2)
                target_rect = pygame.Rect(blue_pos[0], blue_pos[1], blue_size, blue_size)
                if ball_rect.colliderect(target_rect):
                    score += 1
                    state = "hit"
                    hit_timer = 20
                elif traveled_distance >= throw_params["length"]:
                    state = "laser"
                    laser_timer = 20
            elif throw_type == "s":
                ball_pos[0] = float(math_funcs.update_coord(c_double(ball_pos[0]), c_double(throw_speed)))
                dx = ball_pos[0] - ball_start[0]
                # Use calc_sin for the sine value.
                angle_val = 2 * math.pi * dx / throw_params["wave_length"]
                sine_val = float(math_funcs.calc_sin(c_double(angle_val)))
                ball_pos[1] = ball_start[1] + throw_params["wave_amplitude"] * sine_val
                ball_rect = pygame.Rect(int(ball_pos[0] - ball_radius),
                                        int(ball_pos[1] - ball_radius),
                                        ball_radius * 2, ball_radius * 2)
                target_rect = pygame.Rect(blue_pos[0], blue_pos[1], blue_size, blue_size)
                if ball_rect.colliderect(target_rect):
                    score += 3
                    state = "hit"
                    hit_timer = 20
            elif throw_type == "a":
                ball_pos[0] = float(math_funcs.update_coord(c_double(ball_pos[0]), c_double(vx)))
                ball_pos[1] = float(math_funcs.update_coord(c_double(ball_pos[1]), c_double(vy)))
                dx = ball_pos[0] - ball_start[0]
                dy = ball_pos[1] - ball_start[1]
                traveled_distance = math.sqrt(dx * dx + dy * dy)
                ball_rect = pygame.Rect(int(ball_pos[0] - ball_radius),
                                        int(ball_pos[1] - ball_radius),
                                        ball_radius * 2, ball_radius * 2)
                target_rect = pygame.Rect(blue_pos[0], blue_pos[1], blue_size, blue_size)
                if ball_rect.colliderect(target_rect):
                    score += 2
                    state = "hit"
                    hit_timer = 20
                elif traveled_distance >= throw_params["length"]:
                    state = "laser"
                    laser_timer = 20
            elif throw_type == "x":
                ball_pos[0] = float(math_funcs.update_coord(c_double(ball_pos[0]), c_double(vx)))
                ball_pos[1] = float(math_funcs.update_coord(c_double(ball_pos[1]), c_double(vy)))
                # Update vertical velocity using apply_gravity.
                vy = float(math_funcs.apply_gravity(c_double(vy), c_double(gravity)))
                ball_rect = pygame.Rect(int(ball_pos[0] - ball_radius),
                                        int(ball_pos[1] - ball_radius),
                                        ball_radius * 2, ball_radius * 2)
                target_rect = pygame.Rect(blue_pos[0], blue_pos[1], blue_size, blue_size)
                if ball_rect.colliderect(target_rect):
                    score += 5
                    state = "hit"
                    hit_timer = 20
            if not (0 <= ball_pos[0] <= screen_width and 0 <= ball_pos[1] <= screen_height):
                state = "reset"

        # -------------------- Laser and Hit States --------------------
        if state == "laser":
            laser_timer -= 1
            if laser_timer <= 0:
                state = "reset"
        if state == "hit":
            hit_timer -= 1
            if hit_timer <= 0:
                state = "reset"

        # -------------------- Reset State: Prepare for Next Throw --------------------
        if state == "reset":
            ball_pos = [allowed_rect.centerx, allowed_rect.centery]
            blue_pos = get_blue_square_pos()
            state = "ready"
            throw_type = None
            throw_params = {}
            if game_mode == "cpu":
                turn = "cpu" if turn == "player" else "player"
                cpu_wait_start = None

        # -------------------- Drawing Section --------------------
        screen.blit(background, (0, 0))
        pygame.draw.rect(screen, (0, 0, 0), allowed_rect, 2)
        screen.blit(basket_img, (blue_pos[0], blue_pos[1]))
        score_text = font.render("Score: " + str(score), True, (0, 0, 0))
        screen.blit(score_text, (screen_width - 150, 10))
        if game_mode == "cpu":
            turn_text = "Player's Turn" if turn == "player" else "CPU's Turn"
            turn_surface = font.render(turn_text, True, (0, 0, 0))
            screen.blit(turn_surface, (50, 50))
        if state == "laser":
            pygame.draw.line(screen, (0, 255, 0), (screen_width, 0),
                             (int(ball_pos[0]), int(ball_pos[1])), 3)
        ball_hue = (ball_hue + 0.005) % 1.0
        current_color = get_rainbow_color(ball_hue)
        if abs(ball_pos[0] - prev_ball_pos[0]) + abs(ball_pos[1] - prev_ball_pos[1]) > 0.5:
            ball_angle += 5
        ball_surf = create_ball_surface(current_color, ball_radius)
        rotated_ball = pygame.transform.rotate(ball_surf, ball_angle)
        rot_rect = rotated_ball.get_rect(center=(int(ball_pos[0]), int(ball_pos[1])))
        screen.blit(rotated_ball, rot_rect)
        pygame.display.flip()
        clock.tick(60)
        prev_ball_pos = ball_pos.copy()
